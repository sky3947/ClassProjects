Author: Steven Yu (sky3947)

Files:
 - Data.java        |
 - EtherHeader.java |
 - Header.java      |
 - ICMPHeader.java  |
 - IPHeader.java    |
 - Packet.java      |
 - pktanalyzer.java | Contains main method
 - readme.txt       | This file
 - TCPHeader.java   |
 - UDPHeader.java   |
 - Utility.java     |

Compile using:
    javac *.java

Usage: java pktanalyzer <datafile>
       <datafile> : The path to the packet to analyze